var ws = new WebSocket("ws://35.222.69.78:42069");
var salt;
ws.onopen = function () {
    ws.onmessage = function (event) {
        if (JSON.parse(event.data) != null) {
            var msg = JSON.parse(event.data);
            if (msg.type != null) {
                if (msg.type == "console") {
                    if (msg.data != null) {
                        var split = decodeURI(msg.data).split("\n");
                        var text = "";
                        var lines = 25;
                        for (let i = (split.length > lines ? split.length-lines : 0); i < split.length; i++) {
                            text += split[i] + (i != split.length - 1 ? "\n" : "");
                        }
                        document.getElementById("console").innerText = text;
                    }
                }
                else if (msg.type == "ping") {
                    if (msg.data != null) {
                        ws.send("{\"type\":\"pong\",\"data\":" + msg.id + "}");
                    }
                }
                else if (msg.type == "id") {
                    if (msg.data != null) {
                        salt = parseInt(msg.data.toString().substr(msg.data.length - 6));
                        var date = new Date();
                        var time = parseInt((date.getTime()/5000).toString().split(".")[0])+(6398+salt);
                        ws.send("{\"type\":\"auth\",\"id\":\"" + msg.data.substr(0,2) + msg.data.charAt(1) + "\",\"psw\":\"" + sha256(Password+""+ time) + "\",\"usr\":\"" + sha256(Username+""+ time) + "\"}")
                    }
                }
            }
        }
    }
}
ws.onerror = function (error) { console.log("WebSocket error: " + error); };

function send(cmd) {
    var date = new Date();
    var time = parseInt((date.getTime()/5000).toString().split(".")[0])+(717751+salt);
    ws.send(encodeURI("{\"type\":\"cmd\",\"psw\":\"" + sha256(Password+""+ time) + "\",\"usr\":\"" + sha256(Username+""+ time) + "\",\"data\":\"" + encodeURI(cmd) + "\"}"))
}
function chat(msg, color, name) {
    var rainbow = ["dark_red","gold","yellow","green","dark_green","dark_aqua","dark_blue","dark_purple","light_purple"];
    color = (color == "rainbow" ? rainbow[Math.round(Math.random()*(rainbow.length-1))] : color);
    send("tellraw @a [{\\\"text\\\":\\\"<\\\"},{\\\"text\\\":\\\"" + name + "\\\",\\\"color\\\":\\\"" + color + "\\\"},{\\\"text\\\":\\\"> \\\"},{\\\"text\\\":\\\"" + msg + "\\\"}]");
}
function tellraw(text, player) {
    send('tellraw ' + player + ' \\\"' + text + "\\\"")
}
function sendtitle(text,player) {
    send('title ' + player + ' title \\\"' + text + "\\\"");
}
function actionbar(text,player) {
    send('title ' + player + ' actionbar \\\"' + text + "\\\"");
}
function joined(name,color) {
    var rainbow = ["dark_red","gold","yellow","green","dark_green","dark_aqua","dark_blue","dark_purple","light_purple"];
    color = (color == "rainbow" ? rainbow[Math.round(Math.random()*(rainbow.length-1))] : color);
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"yellow\\\",\\\"text\\\":\\\" joined the game\\\"}]")
}
function left(name,color) {
    var rainbow = ["dark_red","gold","yellow","green","dark_green","dark_aqua","dark_blue","dark_purple","light_purple"];
    color = (color == "rainbow" ? rainbow[Math.round(Math.random()*(rainbow.length-1))] : color);
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"yellow\\\",\\\"text\\\":\\\" left the game\\\"}]")
}
function death(name,color,msg) {
    var rainbow = ["dark_red","gold","yellow","green","dark_green","dark_aqua","dark_blue","dark_purple","light_purple"];
    color = (color == "rainbow" ? rainbow[Math.round(Math.random()*(rainbow.length-1))] : color);
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"white\\\",\\\"text\\\":\\\" " + msg + "\\\"}]")
}