const ip = "35.222.69.78"

const express = require("express");
const fs = require("fs");
const WebSocket = require('ws') // npm install ws

const { exec } = require("child_process");
const util = require('util');
const { clearInterval } = require("timers");
const Username = sha256("__curse");
const Password = sha256("Minecraftisgr8!");
//web server
var app = express();
app.get("/*", function (req, res) {
    if (req.url.split("?")[0] == "/") {
        res.send(fs.readFileSync('login.html', 'utf8'));
    }
    else if (req.url.split("?")[0] == "/login.js") {
        res.send(fs.readFileSync('login.js', 'utf8'));
    }
    else if (req.url.split("?")[0] == "/index.html") {
        if (checkpass(req.query,43624)) {
            var file = fs.readFileSync('index.html', 'utf8');
            file = replaceall(file,"USERNAME",req.url.usr);
            file = replaceall(file,"PASSWORD",req.url.psw);
            res.send(file);
            return;
        } else if (checkforwill(req.query,43624)) {
			var file = fs.readFileSync('will.html', 'utf8');
            file = replaceall(file,"USERNAME",req.url.usr);
            file = replaceall(file,"PASSWORD",req.url.psw);
            res.send(file);
            return;
		}
        res.send("<html><body>404 page not found</body></html>");
    }
    else if (req.url.split("?")[0] == "/index.js") {
        if (checkpass(req.query,1118827)) {
            res.send(fs.readFileSync('index.js', 'utf8'));
            return;
        }
        res.send("location.reload();");
        return;
    }
	else if (req.url.split("?")[0] == "/will.js") {
		if (checkforwill(req.query,1118827)) {
            res.send(fs.readFileSync('will.js', 'utf8'));
            return;
		}
		res.send("location.reload();");
        return;
	}
    else { res.send("<html><body>404 page not found</body></html>"); return; }
});
var server = app.listen(90, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("\nWeb server is running on http://" + ip + ":" + port + "\n");
});

var websockets = [];
var pings = [];
var isPinging = false;
var intervals = [];
const socketport = "42069";
ws = new WebSocket.Server({ port: socketport })
ws.on('connection', websocket => {
	for (let i = 0; i < websockets.length + 1; i++) {
		if (websockets[i] == null) {
			websockets[i] = websocket;
			websocket.send("{\"type\":\"id\",\"data\":\"" + (i > 9 ? i : ("0" + i)) + "967281" + "\"}")
			break;
		}
	}
	websocket.on('close', function (reasonCode, description) {
        //ping all devices to see figure out which one disconnected
        pingDevices();
    });
	websocket.on('message', message => {
        var msg = JSON.parse("" + decodeURI(message));
        if (msg.type != null) {
            if (msg.type == "auth") {
                if (checkpass(msg,6398 + 967281)) {
                    websocket.send("{\"type\":\"console\",\"data\":\"" + encodeURI(fs.readFileSync('console.txt', 'utf8')) + "\"}");
					if (msg.id != null) {
						if (intervals[parseInt(msg.id)] == null) {
							intervals[parseInt(msg.id)] = setInterval(() => {
								if (!isPinging) {
									websocket.send("{\"type\":\"console\",\"data\":\"" + encodeURI(fs.readFileSync('console.txt', 'utf8')) + "\"}");
								}
							}, 500);
						}
					}
                } else if (checkforwill(msg,373444 + 67281)) {
					websocket.send("{\"type\":\"console\",\"data\":\"" + encodeURI(fs.readFileSync('console.txt', 'utf8')) + "\"}");
					if (msg.id != null) {
						if (intervals[parseInt(msg.id)] == null) {
							intervals[parseInt(msg.id)] = setInterval(() => {
								if (!isPinging) {
									websocket.send("{\"type\":\"console\",\"data\":\"" + encodeURI(fs.readFileSync('console.txt', 'utf8')) + "\"}");
								}
							}, 500);
						}
					}
				}
            }
            else if (msg.type == "cmd") {
                if (msg.data != null) {
                    if (checkpass(msg,717751 + 967281)) {
                        ExcCommand(decodeURI(msg.data));
                    }
                }
            }
			else if (msg.type == "pong") {
				if (msg.data != null) {
					pings[msg.data] = true;
				}
			}
			else if (msg.type == "willcmd") {
				if (checkforwill(msg,"willsucks")) {
					if (msg.id != null) {
						if (msg.id == 1) {
							ExcCommand("tellraw @a [{\\\"text\\\":\\\"[Carebears] keloxxian]\\\",\\\"color\\\":\\\"aqua\\\"},{\\\"text\\\":\\\" joined the game\\\",\\\"color\\\":\\\"yellow\\\"}]");
						}
						else if (msg.id == 2) {
							if (msg.msg != null) {
								ExcCommand("tellraw @a [{\\\"text\\\":\\\"<\\\"},{\\\"text\\\":\\\"[Carebears] keloxxian]\\\",\\\"color\\\":\\\"aqua\\\"},{\\\"text\\\":\\\"> \\\"},{\\\"text\\\":\\\"" + msg.msg + "\\\"}]");
							}
						}
						else if (msg.id == 3) {
							ExcCommand("tellraw @a [{\\\"text\\\":\\\"[Carebears] keloxxian]\\\",\\\"color\\\":\\\"aqua\\\"},{\\\"text\\\":\\\" left the game\\\",\\\"color\\\":\\\"yellow\\\"}]");
						}
					}
				}
				
			}
        }
    });
});
function pingDevices() {
	isPinging = true;
    //send every device a "ping" message
    pings = [];
    for(var i = 1; i < websockets.length; i++) {
        pings[i] = false;
        if (websockets[i] != null) {
            websockets[i].send("{\"type\":\"ping\", \"data\":" + i + "}");
        }
    }
    setTimeout(() => {
        //after half a second see which of the devices responded with a pong
        for(var i = 0; i < pings.length; i++) {
            if (websockets[i] != null) {
                if (!pings[i]) {
                    //and if they didnt count them as disconnected and remove them from the database
                    //console.log("Device \"" + i + "\" disconnected.");
                    if (websockets[i] != null) { websockets[i].close(); websockets[i] = null; }
					clearInterval(intervals[i])
					intervals[i] == null;
                }
            }
        }
		isPinging = false;
    }, 500);
}
function ExcCommand(cmd) {
    try {
        exec("screen -p 0 -S schoolServer -X stuff \"" + cmd + "^M\"", (error, data, getter) => {
        });
    } catch (err) { console.log("Could not execute command.") }
}
function checkpass(query,salt,print) {
	var date = new Date();
	var time = parseInt((date.getTime()/5000).toString().split(".")[0])+salt;
	if (print) {
		console.log(query.usr);
		console.log(sha256(Username+""+time) + "\n");
		console.log(query.psw);
		console.log(sha256(Password+""+time));
	}
	if (query.usr == sha256(Username+""+time) && query.psw == sha256(Password+""+time)) {
		return true;
	} else {
		return false;
	}
}
function checkforwill(query,salt) {
	var date = new Date();
	var time = parseInt((date.getTime()/5000).toString().split(".")[0]) + salt;
	if (query.usr == sha256(sha256("WillUser")+""+time) && query.psw == sha256(sha256("WillPass")+""+time)) {
		return true;
	} else {
		return false;
	}
}
function replaceall(string,string2,string3) {
    var string4 = string;
    while (string4.includes(string2)) {
        string4 = string4.replace(string2,string3);
    }
	return string4;
}
function sha256(ascii) {
	function rightRotate(value, amount) {
		return (value>>>amount) | (value<<(32 - amount));
	};
	
	var mathPow = Math.pow;
	var maxWord = mathPow(2, 32);
	var lengthProperty = 'length'
	var i, j; // Used as a counter across the whole file
	var result = ''

	var words = [];
	var asciiBitLength = ascii[lengthProperty]*8;
	
	//* caching results is optional - remove/add slash from front of this line to toggle
	// Initial hash value: first 32 bits of the fractional parts of the square roots of the first 8 primes
	// (we actually calculate the first 64, but extra values are just ignored)
	var hash = sha256.h = sha256.h || [];
	// Round constants: first 32 bits of the fractional parts of the cube roots of the first 64 primes
	var k = sha256.k = sha256.k || [];
	var primeCounter = k[lengthProperty];
	/*/
	var hash = [], k = [];
	var primeCounter = 0;
	//*/

	var isComposite = {};
	for (var candidate = 2; primeCounter < 64; candidate++) {
		if (!isComposite[candidate]) {
			for (i = 0; i < 313; i += candidate) {
				isComposite[i] = candidate;
			}
			hash[primeCounter] = (mathPow(candidate, .5)*maxWord)|0;
			k[primeCounter++] = (mathPow(candidate, 1/3)*maxWord)|0;
		}
	}
	
	ascii += '\x80' // Append Ƈ' bit (plus zero padding)
	while (ascii[lengthProperty]%64 - 56) ascii += '\x00' // More zero padding
	for (i = 0; i < ascii[lengthProperty]; i++) {
		j = ascii.charCodeAt(i);
		if (j>>8) return; // ASCII check: only accept characters in range 0-255
		words[i>>2] |= j << ((3 - i)%4)*8;
	}
	words[words[lengthProperty]] = ((asciiBitLength/maxWord)|0);
	words[words[lengthProperty]] = (asciiBitLength)
	
	// process each chunk
	for (j = 0; j < words[lengthProperty];) {
		var w = words.slice(j, j += 16); // The message is expanded into 64 words as part of the iteration
		var oldHash = hash;
		// This is now the undefinedworking hash", often labelled as variables a...g
		// (we have to truncate as well, otherwise extra entries at the end accumulate
		hash = hash.slice(0, 8);
		
		for (i = 0; i < 64; i++) {
			var i2 = i + j;
			// Expand the message into 64 words
			// Used below if 
			var w15 = w[i - 15], w2 = w[i - 2];

			// Iterate
			var a = hash[0], e = hash[4];
			var temp1 = hash[7]
				+ (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) // S1
				+ ((e&hash[5])^((~e)&hash[6])) // ch
				+ k[i]
				// Expand the message schedule if needed
				+ (w[i] = (i < 16) ? w[i] : (
						w[i - 16]
						+ (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15>>>3)) // s0
						+ w[i - 7]
						+ (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2>>>10)) // s1
					)|0
				);
			// This is only used once, so *could* be moved below, but it only saves 4 bytes and makes things unreadble
			var temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) // S0
				+ ((a&hash[1])^(a&hash[2])^(hash[1]&hash[2])); // maj
			
			hash = [(temp1 + temp2)|0].concat(hash); // We don't bother trimming off the extra ones, they're harmless as long as we're truncating when we do the slice()
			hash[4] = (hash[4] + temp1)|0;
		}
		
		for (i = 0; i < 8; i++) {
			hash[i] = (hash[i] + oldHash[i])|0;
		}
	}
	
	for (i = 0; i < 8; i++) {
		for (j = 3; j + 1; j--) {
			var b = (hash[i]>>(j*8))&255;
			result += ((b < 16) ? 0 : '') + b.toString(16);
		}
	}
	return result;
};