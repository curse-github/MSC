var ws = new WebSocket("ws://35.222.69.78:42069");
ws.onopen = function () {
    ws.onmessage = function (event) {
        if (JSON.parse(event.data) != null) {
            var msg = JSON.parse(event.data);
            if (msg.type != null) {
                if (msg.type == "console") {
                    if (msg.data != null) {
                        var split = decodeURI(msg.data).split("\n");
                        var text = "";
                        var lines = 25;
                        for (let i = (split.length > lines ? split.length-lines : 0); i < split.length; i++) {
                            text += split[i] + (i != split.length - 1 ? "\n" : "");
                        }
                        document.getElementById("console").innerText = text;
                    }
                }
                else if (msg.type == "ping") {
                    if (msg.data != null) {
                        ws.send("{\"type\":\"pong\",\"data\":" + msg.id + "}");
                    }
                }
                else if (msg.type == "id") {
                    if (msg.data != null) {
                        ws.send("{\"type\":\"auth\",\"id\":" + msg.data + ",\"psw\":\"" + Password + "\",\"usr\":\"" + Username + "\"}")
                    }
                }
            }
        }
    }
}
ws.onerror = function (error) { console.log("WebSocket error: " + error); };

function send(cmd) {
    ws.send("{\"type\":\"cmd\",\"psw\":\"" + Password + "\",\"usr\":\"" + Username + "\",\"data\":\"" + encodeURI(cmd) + "\"}")
}
function chat(msg, color, name) {
    send("tellraw @a [{\\\"text\\\":\\\"<\\\"},{\\\"text\\\":\\\"" + name + "\\\",\\\"color\\\":\\\"" + color + "\\\"},{\\\"text\\\":\\\"> \\\"},{\\\"text\\\":\\\"" + msg + "\\\"}]");
}
function tellraw(text, player) {
    send('tellraw ' + player + ' \\\"' + text + "\\\"")
}
function sendtitle(text,player) {
    send('title ' + player + ' title \\\"' + text + "\\\"");
}
function actionbar(text,player) {
    send('title ' + player + ' actionbar \\\"' + text + "\\\"");
}
function joined(name,color) {
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"yellow\\\",\\\"text\\\":\\\" joined the game\\\"}]")
}
function left(name,color) {
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"yellow\\\",\\\"text\\\":\\\" left the game\\\"}]")
}
function death(name,color,msg) {
    send("tellraw @a [{\\\"color\\\":\\\"" + color + "\\\",\\\"text\\\":\\\"" + name + "\\\"},{\\\"color\\\":\\\"white\\\",\\\"text\\\":\\\" " + msg + "\\\"}]")
}