rm console.txt
touch console.txt
screen -dmS schoolServer sh "cmd.sh"
