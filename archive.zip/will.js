var ws = new WebSocket("ws://35.222.69.78:42069");
var salt;
ws.onopen = function () {
    ws.onmessage = function (event) {
        if (JSON.parse(event.data) != null) {
            var msg = JSON.parse(event.data);
            if (msg.type != null) {
                if (msg.type == "console") {
                    if (msg.data != null) {
                        var split = decodeURI(msg.data).split("\n");
                        var text = "";
                        var lines = 25;
                        for (let i = (split.length > lines ? split.length-lines : 0); i < split.length; i++) {
                            text += split[i] + (i != split.length - 1 ? "\n" : "");
                        }
                        document.getElementById("console").innerText = text;
                    }
                }
                else if (msg.type == "ping") {
                    if (msg.data != null) {
                        ws.send("{\"type\":\"pong\",\"data\":" + msg.id + "}");
                    }
                }
                else if (msg.type == "id") {
                    if (msg.data != null) {
                        salt = parseInt(msg.data.substr(msg.data.length - 5));
                        var date = new Date();
                        var time = parseInt((date.getTime()/5000).toString().split(".")[0])+(373444+salt);
                        ws.send("{\"type\":\"auth\",\"id\":\"" + msg.data.charAt(0) + msg.data.charAt(1) + "\",\"psw\":\"" + sha256(Password+""+ time) + "\",\"usr\":\"" + sha256(Username+""+ time) + "\"}")
                    }
                }
            }
        }
    }
}
ws.onerror = function (error) { console.log("WebSocket error: " + error); };

function cmdone() {
    var date = new Date();
    var time = parseInt((date.getTime()/5000).toString().split(".")[0])+"willsucks";
    ws.send("{\"type\":\"willcmd\",\"id\":\"1\",\"psw\":\"" + sha256(Password+""+time) + "\",\"usr\":\"" + sha256(Username+""+time) + "\"}")
}
function cmdtwo(msg) {
    var date = new Date();
    var time = parseInt((date.getTime()/5000).toString().split(".")[0])+"willsucks";
    ws.send("{\"type\":\"willcmd\",\"id\":\"2\",\"psw\":\"" + sha256(Password+""+time) + "\",\"usr\":\"" + sha256(Username+""+time) + "\",\"msg\":\"" + encodeURI(msg) + "\"}")
}

function cmdthree() {
    var date = new Date();
    var time = parseInt((date.getTime()/5000).toString().split(".")[0])+"willsucks";
    ws.send("{\"type\":\"willcmd\",\"id\":\"3\",\"psw\":\"" + sha256(Password+""+time) + "\",\"usr\":\"" + sha256(Username+""+time) + "\"}")
}
